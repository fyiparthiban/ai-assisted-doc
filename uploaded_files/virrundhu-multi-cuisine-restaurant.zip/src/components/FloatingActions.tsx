import React from 'react';
import { Phone, MessageCircle } from 'lucide-react';
import { motion } from 'motion/react';

export default function FloatingActions() {
  return (
    <div className="floating-btn">
      <motion.a
        href="https://wa.me/919042221311"
        target="_blank"
        rel="noopener noreferrer"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        className="action-icon bg-green-500"
        title="Order on WhatsApp"
      >
        <MessageCircle className="w-6 h-6" />
      </motion.a>
      <motion.a
        href="tel:+919042221311"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        className="action-icon bg-earth-gold"
        title="Call Now"
      >
        <Phone className="w-6 h-6" />
      </motion.a>
    </div>
  );
}
